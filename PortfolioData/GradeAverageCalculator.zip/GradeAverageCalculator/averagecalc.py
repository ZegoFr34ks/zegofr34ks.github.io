matières_strings = ["EPS", "SciencePC", "ScienceSVT", "PhysiqueChimie", "Philosophie", "Allemand", "Anglais", "AnglaisLitt", "HistoireGéographie", "EMC", "Mathématiques"]

matières = []
for s in matières_strings:
    input_string = input("{}: ".format(s))
    
    try:
        val = int(input_string) 

        matières.append(val)
    except ValueError:

        pass
        
sumOf = sum(matières)

print(sumOf)

average = sumOf/len(matières) 

print("\nTa moyenne est de: " + str(average))

save = input("\nVeut tu sauvegarder cette moyenne comme ta nouvelle moyenne? (y/*): ")

if save == "y":
    print("\nsaving value: " + str(average) + " as new value...")
    file2write = open("currentValue", 'w')
    file2write.write(str(average))
    file2write.close()
    print("succesfully saved!")


    