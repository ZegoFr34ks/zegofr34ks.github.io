#include <iostream>
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <string>
using namespace std;
//variables
string cmd;
bool run = true;
bool rrun = true;
string ncmd;
bool scan = false;
string ipv4[] = { "203.0.113.195", "134.1.444.935", "628.7.362.967",
"398.6.132.938" };
void exit() {
	run = false;
}
void netsh(int RandIndex) {
	//internet command
	cout << endl << "connecting to the network..." << endl;
	Sleep(750);
	cout << "scanning network..." << endl;
	Sleep(500);
	cout << "scan succesfully completed" << endl;
	scan = false;
	while (rrun == true) {
		cout << endl << "\\netsh>";
		cin >> ncmd;
		cout << endl;
		if (ncmd == "scan" || ncmd == "s") {
			cout << endl << "scanning available networks..." << endl;
			Sleep(1200);
			cout << "scan succesfully completed" << endl;
			Sleep(800);
			cout << "Available IP:" << ipv4[RandIndex] << endl << endl;
			scan = true;
		}
		else if (ncmd == "getip" || ncmd == "g") {
			if (scan == true) {
				cout << "insert rdn ip code here!" << endl;
			}
			else {
				cout << "Error: Try scanning for available networks" << endl;
			}
		}
		else if (ncmd == "help" || ncmd == "h") {
			cout << "-scan : scans available networks" << endl << "-getip : get 
				available networks via ipv4"
				<< endl << "-help : get netsh commands" << endl;
		}
		else if (ncmd == "exit" || ncmd == "e") {
			cout << "exiting netsh..." << endl;
			rrun = false;
		}
		else {
			//error
			cout << "Error: Kalix could not understand what you are trying to say 
				please try again or head to our forum for our documentation or help from other members
				of our community" << endl;
		}
	}
}
void getCommand(string cmd, int RandIndex) {
	rrun = false;
	if (cmd == "netsh" || cmd == "n") {
		rrun = true;
		netsh(RandIndex);
	}
	else if (cmd == "help" || cmd == "h") {
		//shows all commands
		cout << "-netsh : access to netsh tool" << endl
			<< "-version : prompts Kalix's version"
			<< endl << "-exit : quits Kalix" << endl
			<< "-keylog : access to keylogger" << endl
			<< "-macro : access to macro" << endl
			<< "-bruteforce : crack passwords by brute force"
			<< endl << "-calc : calculate simple math problems"
			<< endl;
	}
	else if (cmd == "version" || cmd == "v") {
		//shows program version
		cout << "Kalix is currently on version v0.04" << endl;
		cout << "Checking for updates... please wait" << endl;
		Sleep(2000);
		cout << "no updates found" << endl;
	}
	else if (cmd == "exit" || cmd == "e") {
		//quits program
		cout << "exit in progress..." << endl;
		Sleep(1000);
		exit();
	}
	else if (cmd == "keylog" || cmd == "k") {
		//keylogger
		cout << "This feature will be coming soon *wait for update*" << endl;
		//insert script
	}
	else if (cmd == "macro" || cmd == "m") {
		//macro
		cout << "This feature will be coming soon *wait for update*" << endl;
		//insert script
	}
	else if (cmd == "bruteforce" || cmd == "b") {
		//password cracker
		cout << "This feature will be coming soon *wait for update*" << endl;
		//insert script
	}
	else if (cmd == "cheat" || cmd == "ch") {
		//cheat for program *unknown*
		cout << "This feature will be coming soon *wait for update*" << endl;
		//insert script
	}
	else if (cmd == "debug" || cmd == "d") {
		//template code
		cout << "this a debug tool!" << endl;
	}
	else if (cmd == "calc" || cmd == "c") {
		char op;
		int num1, num2;
		cout << "you will first be asked to enter an operator and then your two 
			numbers" << endl;
			cout << "Enter operator either + or - or * or /: ";
		cin >> op;
		cout << "Enter first operand: ";
		cin >> num1;
		cout << "Enter second operand: ";
		cin >> num2;
		if (isdigit(num1) == false || isdigit(num2) == false) {
			switch (op)
			{
			case '+':
				cout << num1 + num2 << endl;
				break;
			case '-':
				cout << num1 - num2 << endl;
				break;
			case '*':
				cout << num1 * num2 << endl;
				break;
			case '/':
				cout << num1 / num2 << endl;
				break;
			default:
				// If the operator is other than +, -, * or /, error message is shown
				cout << "Error! operator is not correct" << endl;
				break;
			}
		}
		else {
			cout << "Error! Invalid Values // " << num1 << " " << num2 << endl; //num 
			is string!!
		}
	}
	else {
		//error
		cout << "Error: Kalix could not understand what you are trying to say please 
			try again or head to our forum for our documentation or help from other members of our
			community" << endl;
	}
}
void prompt(int RandIndex) {
	while (run == true) {
		cout << "please enter your command prompt: ";
		cin >> cmd;
		cout << endl;
		cout <<
			"[------------------------------------------------------------------------" << endl;
		getCommand(cmd, RandIndex);
		cout <<
			"------------------------------------------------------------------------]" << endl;
		cout << endl;
	}
}
int main() {
	srand(time(NULL));
	int RandIndex = rand() % 4;
	cout << "--- Welcome To: KALIXTOOL ---" << endl;
	cout << "Keep in mind that this is the beta version of Kalix, more things to 
		come!" << endl;
		cout << "by using our service you approve and accept our privacy policies, and 
		terms of service" << endl << endl;
		prompt(RandIndex);
}
int main();
