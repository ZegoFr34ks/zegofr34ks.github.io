import discord
import random
import os
import asyncio
import datetime
from discord.ext import commands, tasks
from discord.utils import get
from random import choice

client = commands.Bot(command_prefix="+")

@client.event
async def on_ready():
    print("~Booted!")


@client.command()
@commands.has_guild_permissions(administrator=True)
async def giveaway(ctx, mins : int, * , prize: str):

    await ctx.send("@everyone")

    embed=discord.Embed(title="Giveaway!")
    embed.add_field(name="Prize", value=f"{prize}")
    end = datetime.datetime.utcnow() + datetime.timedelta(seconds = mins*60)
    end = end - datetime.timedelta(microseconds=end.microsecond)
    embed.add_field(name="Ends At:", value=f"{end} UTC")
    embed.set_footer(text=f"End {mins} min(s) from now!")

    my_msg = await ctx.send(embed=embed)

    await my_msg.add_reaction("🎉")

    await asyncio.sleep(mins*60)

    new_msg = await ctx.channel.fetch_message(my_msg.id)

    users = await new_msg.reactions[0].users().flatten()
    users.pop(users.index(client.user))

    #winner = random.choice(users)
    winner = await ctx.guild.fetch_member(0000000000000) #input user
    
    await ctx.send(f'{winner.mention}' + " Create a ticket to claim reward!")

    embed=discord.Embed(title="Winner!" ,description = f"{winner.mention}")
    embed.set_thumbnail(url=winner.avatar_url)
    embed.add_field(name="Prize", value=f"{prize}")
    embed.set_footer(text="Giveaway Ended!")

    await ctx.send(embed=embed)

    """server = ctx.message.guild

    await winner.send(f"You Won the giveaway in {server.name}")"""


client.run("BOTTOKEN")
